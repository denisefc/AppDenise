package br.edu.infnet.AppDenise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppDeniseApplicationTests {

	@Test
	void contextLoads() {
	}

}

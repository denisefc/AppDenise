package br.edu.infnet.AppDenise.model.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "TPedido")
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Min(value = 1, message = "o numero do pedido deve ser maior ou igual a {value}")
    @Column(unique = true, name = "csnumeroPedido")
    private int numeroPedido;
    @Column(name = "vltotalReais")
    private float totalReais;
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JoinColumn(name = "idPedido")
    private List<MovelMadeira> moveisMadeira;

    public Pedido() {
        this.moveisMadeira = new ArrayList<MovelMadeira>();
    }

    public Pedido(Integer id) {
        this();
        this.setId(id);
    }

    @Override
    public String toString() {
        return String.format("%d - %.2f - %d",
                numeroPedido,
                totalReais,
                moveisMadeira.size()
        );
    }
}
